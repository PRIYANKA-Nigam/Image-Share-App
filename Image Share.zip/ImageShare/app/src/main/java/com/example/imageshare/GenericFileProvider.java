package com.example.imageshare;

import androidx.core.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
